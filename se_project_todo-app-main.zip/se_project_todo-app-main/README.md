# Simple Todo App

Weclome to the Simple To Do App. Kepp your todo list nice and organized with this user friendly and simple todo app.

## Functionality

With the simple to do app your are able to:
- Create todo list items
- Add a spcefic date for each item
- Check the box for each item after the task is completed
- Delete certain items if they are no longer relevant
- Check and see how much of your daily or weekly tasks have been completed.

## Technology

This web app uses a responsive design that works on all screen sizes.
The tech stack envolves the use of HTML,CSS, and JavaScript.
As a main part of this project an Object Oriented Programming approach is used 
in the Javascript code to make it as scalable and resuable as can be!

## Deployment

This project is deployed on GitHub Pages:
- https://seroujk.github.io/se_project_todo-app/
